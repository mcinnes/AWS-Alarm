<?
system('/Applications/VLC.app/Contents/MacOS/VLC ~/Downloads/amazon-polly-demo-php-master/ssml.mp3');
?>